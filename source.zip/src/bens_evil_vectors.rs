use std::cmp;

pub fn value<X: Clone, Y>(x: X) -> impl Fn(Y) -> X
{   move |_| x.clone()   }

pub fn is<X: Eq>(x: X) -> impl Fn(X) -> bool
{   move |y: X| y == x   }

pub fn greater_than<X: Ord>(x: X) -> impl Fn(X) -> bool
{   move |y: X| y > x   }

pub fn less_than<X: Ord>(x: X) -> impl Fn(X) -> bool
{   move |y: X| y < x   }

pub fn within<X: Ord>(min: X, max: X) -> impl Fn(X) -> bool
{   move |y: X| min <= y && max >= y   }

pub fn set_within<X: Ord>(min: X, max: X, x: X) -> X
{   cmp::max(min, cmp::min(x, max))   }

pub fn tuple<X: Clone, Y: Clone>(x: X, y: Y) -> (X, Y)
{   (x, y)   }

pub trait Tuple<X, Y> {
    fn apply<Z, F>(self: &Self, f: F) -> Z where F: Fn(X, Y) -> Z;
    fn apply_fst<Z, F>(self: &Self, f: F) -> (Z, Y) where F: Fn(X) -> Z;
    fn apply_snd<Z, F>(self: &Self, f: F) -> (X, Z) where F: Fn(Y) -> Z;
}
impl<X: Clone, Y: Clone> Tuple<X, Y> for (X, Y) {
    fn apply<Z, F>(self: &Self, f: F) -> Z where F: Fn(X, Y) -> Z
    {   f(self.0.clone(), self.1.clone())   }

    fn apply_fst<Z, F>(self: &Self, f: F) -> (Z, Y) where F: Fn(X) -> Z
    {   (f(self.0.clone()), self.1.clone())   }

    fn apply_snd<Z, F>(self: &Self, f: F) -> (X, Z) where F: Fn(Y) -> Z
    {   (self.0.clone(), f(self.1.clone()))   }
}


pub trait FuncList<X> {
    fn indices(self: &Self) -> impl Iterator<Item=usize>;
    fn reverse(self: &Self) -> Vec<X>;
    fn slice(self: &Self, start: usize, end: usize) -> Vec<X>;
    fn slicefrom(self: &Self, start: usize) -> Vec<X>;
    fn fold<A, F>(self: &Self, init: A, f: F) -> A where F: Fn(A, X) -> A;
    fn map<Y, F>(self: &Self, f: F) -> Vec<Y> where F: Fn(X) -> Y;
    fn zipwith<Y: Clone, Z, F>(self: &Self, list: &Vec<Y>, f: F) -> Vec<Z> where F: Fn(X, Y) -> Z;
    fn zip<Y: Clone>(self: &Self, list: &Vec<Y>) -> Vec<(X, Y)>;
    fn zipwmap<Y: Clone, F>(self: &Self, f: F) -> Vec<(X, Y)> where F: Fn(X) -> Y;
    fn filter<F>(self: &Self, f: F) -> Vec<X> where F: Fn(X) -> bool;
    fn count<F>(self: &Self, f: F) -> usize where F: Fn(X) -> bool;
    fn contains<F>(self: &Self, f: F) -> bool where F: Fn(X) -> bool;
    fn find<F>(self: &Self, f: F) -> Vec<usize> where F: Fn(X) -> bool;
    fn find1st<F>(self: &Self, f: F) -> usize where F: Fn(X) -> bool;
}
impl<X: Clone> FuncList<X> for Vec<X> {
    fn indices(self: &Self) -> impl Iterator<Item=usize>
    {   0..self.len()   }

    fn reverse(self: &Self) -> Vec<X>
    {   self.iter().rev().map(|x: &X| x.clone()).collect()   }

    fn slice(self: &Self, start: usize, end: usize) -> Vec<X>
    {   (start..end).map(|x| self[x].clone()).collect()   }

    fn slicefrom(self: &Self, start: usize) -> Vec<X>
    {   self.slice(start, self.len())   }

    fn fold<A, F>(self: &Self, init: A, f: F) -> A where F: Fn(A, X) -> A
    {   self.iter().fold(init, |acc, x| f(acc, x.clone()))   }

    fn map<Y, F>(self: &Self, f: F) -> Vec<Y> where F: Fn(X) -> Y
    {   self.iter().map(|x: &X| f(x.clone())).collect()   }

    fn zipwith<Y: Clone, Z, F>(self: &Self, list: &Vec<Y>, f: F) -> Vec<Z> where F: Fn(X, Y) -> Z
    {   (0..cmp::min(self.len(), list.len())).map(|x: usize| f(self[x].clone(), list[x].clone())).collect()   }

    fn zip<Y: Clone>(self: &Self, list: &Vec<Y>) -> Vec<(X, Y)>
    {   self.zipwith(list, tuple)   }

    fn zipwmap<Y: Clone, F>(self: &Self, f: F) -> Vec<(X, Y)> where F: Fn(X) -> Y
    {   (self, &self.map(f)).zip()   }

    fn filter<F>(self: &Self, f: F) -> Vec<X> where F: Fn(X) -> bool
    {   self.iter().filter(|&x| f(x.clone())).map(|x| x.clone()).collect()   }

    fn count<F>(self: &Self, f: F) -> usize where F: Fn(X) -> bool
    {   self.filter(f).len()   }

    fn contains<F>(self: &Self, f: F) -> bool where F: Fn(X) -> bool
    {   self.count(f) > 0   }

    fn find<F>(self: &Self, f: F) -> Vec<usize> where F: Fn(X) -> bool
    {   self.indices().filter(|i| f(self[*i].clone())).collect()   }

    fn find1st<F>(self: &Self, f: F) -> usize where F: Fn(X) -> bool
    {   self.find(f)[0]   }
}


pub trait EqList<X> {
    fn singleton(self: &Self) -> Vec<X>;
    fn group(self: &Self) -> Vec<(X, usize)>;
}
impl<X: Eq + Clone> EqList<X> for Vec<X> {
    fn singleton(self: &Self) -> Vec<X>
    {   self.indices().filter(|i: &usize| !self.slicefrom(i+1).contains(is(self[*i].clone()))).map(|i: usize| self[i].clone()).collect()  }

    fn group(self: &Self) -> Vec<(X, usize)>
    {   self.singleton().zipwmap(|x: X| self.count(is(x)))   }
}


pub trait ZippedList<X, Y> {
    fn rezipwith<Z, F>(self: &Self, f: F) -> Vec<Z> where F: Fn(X, Y) -> Z;
    fn unzip(self: &Self) -> (Vec<X>, Vec<Y>);
}
impl<X: Clone, Y: Clone> ZippedList<X, Y> for Vec<(X, Y)> {
    fn rezipwith<Z, F>(self: &Self, f: F) -> Vec<Z> where F: Fn(X, Y) -> Z
    {   self.map(|xy| xy.apply(&f))   }

    fn unzip(self: &Self) -> (Vec<X>, Vec<Y>)
    {   (self.map(|pair| pair.0), self.map(|pair| pair.1))   }
}


pub trait ListPair<X, Y> {
    fn zipwith<Z, F>(self: &Self, f: F) -> Vec<Z> where F: Fn(X, Y) -> Z;
    fn zip(self: &Self) -> Vec<(X, Y)>;
}
impl<X: Clone, Y: Clone> ListPair<X, Y> for (Vec<X>, Vec<Y>) {
    fn zipwith<Z, F>(self: &Self, f: F) -> Vec<Z> where F: Fn(X, Y) -> Z
    {   self.0.zipwith(&self.1, f)   }
    fn zip(self: &Self) -> Vec<(X, Y)>
    {   self.0.zip(&self.1)   }
}
impl<X: Clone, Y: Clone> ListPair<X, Y> for (&Vec<X>, &Vec<Y>) {
    fn zipwith<Z, F>(self: &Self, f: F) -> Vec<Z> where F: Fn(X, Y) -> Z
    {   self.0.zipwith(&self.1, f)   }
    fn zip(self: &Self) -> Vec<(X, Y)>
    {   self.0.zip(&self.1)   }
}


pub trait DimList<X> {
    fn row(self: &Self, i: usize) -> Vec<X>;
    fn column(self: &Self, i: usize) -> Vec<X>;
    fn gridmap<Y, F>(self: &Self, f: F) -> Vec<Vec<Y>> where F: Fn(X) -> Y;
    fn flatten(self: &Self) -> Vec<X>;
    fn reflect(self: &Self) -> Vec<Vec<X>>;
    fn transpose(self: &Self) -> Vec<Vec<X>>;
    fn rotl(self: &Self) -> Vec<Vec<X>>;
    fn rotr(self: &Self) -> Vec<Vec<X>>;
}
impl<X: Clone> DimList<X> for Vec<Vec<X>> {
    fn row(self: &Self, i: usize) -> Vec<X>
    {   self[i].clone()   }

    fn column(self: &Self, i: usize) -> Vec<X>
    {   self.map(|row| row[i].clone())   }

    fn gridmap<Y, F>(self: &Self, f: F) -> Vec<Vec<Y>> where F: Fn(X) -> Y
    {   self.map(|row| row.map(&f))   }

    fn flatten(self: &Self) -> Vec<X>
    {   self.iter().flatten().map(|x: &X| x.clone()).collect()   }

    fn reflect(self: &Self) -> Vec<Vec<X>>
    {   self.map(|row| row.reverse())   }

    fn transpose(self: &Self) -> Vec<Vec<X>>
    {   self[0].indices().map(|i| self.column(i)).collect()   }

    fn rotl(self: &Self) -> Vec<Vec<X>>
    {   self.reflect().transpose()   }
    
    fn rotr(self: &Self) -> Vec<Vec<X>>
    {   self.transpose().reflect()   }
}