use macroquad::prelude::*;
use crate::gamedata::*;
use crate::gamedata::Tile::*;
use crate::gamedata::Direction::*;
use crate::bens_evil_vectors::{FuncList, Tuple};

pub fn movement_none(_: &mut Guy, _: &Maze) -> bool {
    false
}

pub fn movement_player_default(guy: &mut Guy, maze: &Maze) -> bool {
    if guy.state_movement % 4 > 0 {
        guy.state_movement += 1;
        return false;
    };

    // Attack

    let attack_dir = if is_key_down(KeyCode::W) {Up} else
        if is_key_down(KeyCode::S) {Down} else
        if is_key_down(KeyCode::A) {Left} else
        if is_key_down(KeyCode::D) {Right} else
        {None};
    if attack_dir != None {
        let old_pos = guy.pos;
        for _ in 0..2 {
            guy.dirmove(attack_dir);
            if maze.get(guy.pos) != O {
                guy.pos = old_pos;
                break;
            };
            for i in 1..maze.guys.len() {
                if maze.guys[i].pos == guy.pos && maze.guys[i].state_death == 0 {
                    guy.state_movement += 1;
                    return false;
                };
            };
        };
        guy.pos = old_pos;
    };

    guy.dirmove({
        if is_key_down(KeyCode::W) {Up} else
        if is_key_down(KeyCode::S) {Down} else
        if is_key_down(KeyCode::A) {Left} else
        if is_key_down(KeyCode::D) {Right} else
        {None}
    });
    guy.state_movement += 1;
    return false;
}

pub fn movement_player_flask(guy: &mut Guy, maze: &Maze) -> bool {
    if guy.state_movement % 8 > 0 {
        guy.state_movement += 1;
        return false;
    };

    // Attack

    let attack_dir = if is_key_down(KeyCode::W) {Up} else
        if is_key_down(KeyCode::S) {Down} else
        if is_key_down(KeyCode::A) {Left} else
        if is_key_down(KeyCode::D) {Right} else
        {None};
    if attack_dir != None {
        let old_pos = guy.pos;
        guy.dirmove(attack_dir);
        if maze.get(guy.pos) != O {
            guy.pos = old_pos;
        };
        for i in 1..maze.guys.len() {
            println!("{} {:?} {:?}", maze.guys[i].sprite, maze.guys[i].pos, guy.pos);
            if maze.guys[i].pos == guy.pos && maze.guys[i].state_death == 0 {
                guy.state_movement += 1;
                return false;
            };
        };
        guy.pos = old_pos;
    };

    guy.dirmove({
        if is_key_down(KeyCode::W) {Up} else
        if is_key_down(KeyCode::S) {Down} else
        if is_key_down(KeyCode::A) {Left} else
        if is_key_down(KeyCode::D) {Right} else
        {None}
    });
    guy.state_movement += 1;
    return false;
}

pub fn movement_player_lobster(guy: &mut Guy, maze: &Maze) -> bool {
    if guy.state_movement % 2 > 0 {
        guy.state_movement += 1;
        return false;
    };

    // Attack

    let attack_dirs = if is_key_down(KeyCode::W) {(Up, Right)} else
        if is_key_down(KeyCode::S) {(Down, Left)} else
        if is_key_down(KeyCode::A) {(Up, Left)} else
        if is_key_down(KeyCode::D) {(Down, Right)} else
        {(None, None)};
    if attack_dirs != (None, None) {
        let old_pos = guy.pos;
        guy.dirmove(attack_dirs.0);
        guy.dirmove(attack_dirs.1);
        if maze.get(guy.pos) != O {
            guy.pos = old_pos;
        };
        for i in 1..maze.guys.len() {
            println!("{} {:?} {:?}", maze.guys[i].sprite, maze.guys[i].pos, guy.pos);
            if maze.guys[i].pos == guy.pos && maze.guys[i].state_death == 0 {
                guy.state_movement += 1;
                return false;
            };
        };
        guy.pos = old_pos;
    };

    guy.dirmove({
        if is_key_down(KeyCode::W) {Up} else
        if is_key_down(KeyCode::S) {Down} else
        if is_key_down(KeyCode::A) {Left} else
        if is_key_down(KeyCode::D) {Right} else
        {None}
    });
    guy.dirmove({
        if is_key_down(KeyCode::W) {Right} else
        if is_key_down(KeyCode::S) {Left} else
        if is_key_down(KeyCode::A) {Up} else
        if is_key_down(KeyCode::D) {Down} else
        {None}
    });
    guy.state_movement += 1;
    return false;
}

pub fn movement_player_mimic(guy: &mut Guy, maze: &Maze) -> bool {
    if guy.state_movement % 12 > 0 {
        guy.state_movement += 1;
        return false;
    };

    // Attack

    let attack_dir = if is_key_down(KeyCode::W) {Up} else
        if is_key_down(KeyCode::S) {Down} else
        if is_key_down(KeyCode::A) {Left} else
        if is_key_down(KeyCode::D) {Right} else
        {None};
    if attack_dir != None {
        let old_pos = guy.pos;
        let mut landed_attack = false;
        for _ in 0..4 {
            guy.dirmove(attack_dir);
            for i in 1..maze.guys.len() {
                println!("{} {:?} {:?}", maze.guys[i].sprite, maze.guys[i].pos, guy.pos);
                if maze.guys[i].pos == guy.pos && maze.guys[i].state_death == 0 {
                    guy.state_movement += 1;
                    return false;
                };
            };
        };
        guy.pos = old_pos;
    };

    guy.dirmove({
        if is_key_down(KeyCode::W) {Up} else
        if is_key_down(KeyCode::S) {Down} else
        if is_key_down(KeyCode::A) {Left} else
        if is_key_down(KeyCode::D) {Right} else
        {None}
    });
    guy.state_movement += 1;
    return false;
}

pub fn movement_player_pubert(guy: &mut Guy, maze: &Maze) -> bool {
    if guy.state_movement % 8 > 0 {
        guy.state_movement += 1;
        return false;
    };

    // Attack

    let attack_dir = if is_key_down(KeyCode::W) {Up} else
        if is_key_down(KeyCode::S) {Down} else
        if is_key_down(KeyCode::A) {Left} else
        if is_key_down(KeyCode::D) {Right} else
        {None};
    if attack_dir != None {
        let old_pos = guy.pos;
        for _ in 0..2 {
            guy.dirmove(attack_dir);
            for i in 1..maze.guys.len() {
                println!("{} {:?} {:?}", maze.guys[i].sprite, maze.guys[i].pos, guy.pos);
                if maze.guys[i].pos == guy.pos && maze.guys[i].state_death == 0 {
                    guy.state_movement += 1;
                    return false;
                };
            };
        };
        guy.pos = old_pos;
    };

    for _ in 0..2 {
        guy.dirmove({
            if is_key_down(KeyCode::W) {Up} else
            if is_key_down(KeyCode::S) {Down} else
            if is_key_down(KeyCode::A) {Left} else
            if is_key_down(KeyCode::D) {Right} else
            {None}
        });
    };
    guy.state_movement += 1;
    return false;
}

pub fn movement_lobster(guy: &mut Guy, maze: &Maze) -> bool {
    if guy.state_movement % 2 > 0 {
        guy.state_movement += 1;
        return false;
    }
    
    let player_pos = maze.guys[maze.player_index].pos;

    // Attack
    
    let diff = (guy.pos.0 as i32 - player_pos.0 as i32, guy.pos.1 as i32 - player_pos.1 as i32);
    if diff.0.abs() == 1 && diff.1.abs() == 1 {
        guy.state_movement += 1;
        return true;
    };
    
    // Move

    let diff = (guy.pos.0 as i32 - player_pos.0 as i32, guy.pos.1 as i32 - player_pos.1 as i32);
    let mut directions = (
        if diff.1 > 0 {Up} else if diff.1 < 0 {Down} else {None},
        if diff.0 > 0 {Left} else if diff.0 < 0 {Right} else {None}
    );
    let old_pos = guy.pos;
    guy.dirmove(directions.0);
    guy.dirmove(directions.1);
    let diff = pos_diff(guy.pos, old_pos);
    if maze.get(guy.pos) != O || diff.apply(|x, y| x.abs() + y.abs()) != 2 {
        guy.pos = old_pos;
    };

    guy.state_movement += 1;
    return false;
}

pub fn movement_pubert(guy: &mut Guy, maze: &Maze) -> bool {
    if guy.state_movement % 8 > 0 {
        guy.state_movement += 1;
        return false;
    }
    let player_pos = maze.guys[maze.player_index].pos;

    // Attack
    
    let diff = (guy.pos.0 as i32 - player_pos.0 as i32, guy.pos.1 as i32 - player_pos.1 as i32);
    if (diff.0.abs() + diff.1.abs() == 2 && (diff.0.abs() == 0 || diff.1.abs() == 0)) || (diff.0.abs() + diff.1.abs() == 0) {
        return true;
    };
    
    let direction =
        if diff.1 > 1 {Up} else if diff.1 < -1 {Down} else {None};
    let old_pos = guy.pos;
    guy.dirmove(direction);
    guy.dirmove(direction);
    if maze.get(guy.pos) != O || guy.pos == old_pos {
        guy.pos = old_pos;
        let direction =
            if diff.0 > 1 {Left} else if diff.0 < -1 {Right} else {None};
        let old_pos = guy.pos;
        guy.dirmove(direction);
        guy.dirmove(direction);
        if maze.get(guy.pos) != O || guy.pos == old_pos {
            guy.pos = old_pos;
        };
    };

    guy.state_movement += 1;
    return false;
}

pub fn movement_flask(guy: &mut Guy, maze: &Maze) -> bool {
    if guy.state_movement % 8 > 0 {
        guy.state_movement += 1;
        return false;
    }
    
    let player_pos = maze.guys[maze.player_index].pos;
    // Attack
    
    let diff = (guy.pos.0 as i32 - player_pos.0 as i32, guy.pos.1 as i32 - player_pos.1 as i32);
    if diff.0.abs() + diff.1.abs() == 1 && (diff.0.abs() == 0 || diff.1.abs() == 0) {
        return true;
    };
    
    let direction =
        if diff.1 > 0 {Up} else if diff.1 < 0 {Down} else {None};
    let old_pos = guy.pos;
    guy.dirmove(direction);
    if maze.get(guy.pos) != O || guy.pos == old_pos {
        guy.pos = old_pos;
        let direction =
            if diff.0 > 0 {Left} else if diff.0 < 0 {Right} else {None};
        let old_pos = guy.pos;
        guy.dirmove(direction);
        if maze.get(guy.pos) != O || guy.pos == old_pos {
            guy.pos = old_pos;
        };
    };

    guy.state_movement += 1;    
    return false;
}

pub fn movement_mimic(guy: &mut Guy, maze: &Maze) -> bool {
    if guy.state_movement % 12 > 0 {
        guy.state_movement += 1;
        return false;
    }
    
    let player_pos = maze.guys[maze.player_index].pos;

    // Attack
    
    let diff = (guy.pos.0 as i32 - player_pos.0 as i32, guy.pos.1 as i32 - player_pos.1 as i32);
    if diff.0.abs() + diff.1.abs() <= 3 && (diff.0.abs() == 0 || diff.1.abs() == 0) {
        guy.state_movement += 1;
        return true;
    };
    
    // Move

    let diff = (guy.pos.0 as i32 - player_pos.0 as i32, guy.pos.1 as i32 - player_pos.1 as i32);
    let direction =
        if diff.1 > 0 {Up} else if diff.1 < 0 {Down} else {None};
    let old_pos = guy.pos;
    guy.dirmove(direction);
    if maze.get(guy.pos) != O || guy.pos == old_pos {
        guy.pos = old_pos;
        let direction =
            if diff.0 > 0 {Left} else if diff.0 < 0 {Right} else {None};
        let old_pos = guy.pos;
        guy.dirmove(direction);
        if maze.get(guy.pos) != O || guy.pos == old_pos {
            guy.pos = old_pos;
        };
    };

    guy.state_movement += 1;    
    return false;

    guy.state_movement += 1;
    return false;
}


/*

gonna do chars instead of ints actually

S: player

L: lobter
M: mimic
F: potion
P: pubert
U: uncle dragi (like from the mtg card Slitherhead (ask lily))

WILL ADD MORE LATER

*/
pub fn guy_from_char((c, pos): (char, Pos)) -> Guy {
    Guy {
        pos: pos,
        state_movement: 1,
        state_anim: 0,
        state_death: 0,
        velocity: (0, 0),
        last_velocity: (0, 0),
        attack_velocity: (0, 0),
        behaviour: match c {
            'S' => movement_player_default,
            'L' => movement_lobster,
            'P' => movement_pubert,
            'F' => movement_flask,
            'M' => movement_mimic,
            _ => movement_flask
        },
        sprite: c
    }
}