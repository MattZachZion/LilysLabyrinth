use macroquad::prelude::*;
use crate::gamedata::*;
use macroquad::audio::{*};

pub enum GameState {
    Main_Menu,
    Playing,
    You_Win
}

pub struct GameData {
    pub game_state: GameState,
    pub screen_size: Vec<f32>,
    pub scaled_size: Vec<f32>,
    pub screen_offset: Vec<f32>,
    pub game_textures: GameTextures,
    pub game_sounds: GameSounds,
    pub level: Maze,
    pub level_door_open: bool
}

pub struct GameTextures {
    pub main_menu_image: Texture2D,
    pub you_win: Texture2D,
    pub wall: Walls,
    pub generic_floor: Texture2D,
    pub shaded_floor: Texture2D,
    pub player: Vec<Texture2D>,
    pub play: Texture2D,
    pub quit: Texture2D,
    pub enemies: Enemies
}

pub struct Walls {
    pub generic: Texture2D,
    pub top: Texture2D,
    pub middle: Texture2D,
    pub top_right: Texture2D,
    pub top_left: Texture2D,
    pub side_right: Texture2D,
    pub side_left: Texture2D,
    pub blocked: Texture2D,
    pub front: Texture2D,
    pub door_wall: Texture2D,
    pub door_wall_open: Texture2D
}

pub struct Enemies {
    pub lobster: Vec<Texture2D>,
    pub mimic: Vec<Texture2D>,
    pub potion: Vec<Texture2D>,
    pub pubert: Vec<Texture2D>,
    pub uncle_dragi: Vec<Texture2D>
}

pub struct GameSounds {
    pub enemy_impact: Sound,
    pub enemy_soul: Sound,
    pub menu_select: Sound,
    pub player_impact: Sound,
    pub player_soul: Sound,
    pub step: Sound
}