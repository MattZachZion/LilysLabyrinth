use crate::data::*;
use crate::data::GameState::*;
use crate::gamedata::Tile::*;
use macroquad::prelude::*;
use macroquad::audio::{*};

pub fn render_game(
    game_info: &mut GameData
) {
    if game_info.screen_size[0] != screen_width() || game_info.screen_size[1] != screen_height() {
        game_info.screen_size = vec![screen_width() as f32, screen_height() as f32];
        game_info.scaled_size = find_scaled_size(&game_info.screen_size);
        game_info.screen_offset = vec![(game_info.screen_size[0] - game_info.scaled_size[0]) / 2.0, (game_info.screen_size[1] - game_info.scaled_size[1]) / 2.0]
    }
    clear_background(BLACK);
    match game_info.game_state {
        Main_Menu => {
            draw_texture_ex(
                &game_info.game_textures.main_menu_image,
                game_info.screen_offset[0],
                game_info.screen_offset[1],
                WHITE,DrawTextureParams 
                {dest_size: Some(vec2(game_info.scaled_size[0], game_info.scaled_size[1])),..Default::default()} 
            );
            render_options(&vec![game_info.screen_offset[0] + game_info.scaled_size[0] / 3.0, 
                game_info.screen_offset[1] + game_info.scaled_size[1] / 1.8],
                &vec![0.0, game_info.screen_offset[1] + game_info.scaled_size[1]],
                &game_info,
                );
            if is_mouse_button_pressed(MouseButton::Left) {
                    let mouse_position: (f32, f32) = mouse_position();
                    if mouse_position.0 > game_info.screen_offset[0] + game_info.scaled_size[0] / 3.0 && 
                    mouse_position.0 < (game_info.screen_offset[0] + game_info.scaled_size[0] / 3.0) + ((game_info.scaled_size[0] + game_info.screen_offset[0]) - (game_info.screen_offset[0] + game_info.scaled_size[0] / 3.0)) / 2.0 && 
                    mouse_position.1 > game_info.screen_offset[1] + game_info.scaled_size[1] / 1.8 &&
                    mouse_position.1 < game_info.screen_offset[1] + game_info.scaled_size[1] / 1.8 + ((game_info.scaled_size[1] - game_info.scaled_size[1] / 1.8) * 0.45){
                        game_info.game_state = Playing;
                        play_sound_once(&game_info.game_sounds.menu_select)
                    }
                    if mouse_position.0 > game_info.screen_offset[0] + game_info.scaled_size[0] / 3.0 && 
                    mouse_position.0 < (game_info.screen_offset[0] + game_info.scaled_size[0] / 3.0) + ((game_info.scaled_size[0] + game_info.screen_offset[0]) - (game_info.screen_offset[0] + game_info.scaled_size[0] / 3.0)) / 2.0 && 
                    mouse_position.1 > (game_info.screen_offset[1] + game_info.scaled_size[1] / 1.8) + (game_info.scaled_size[1] - game_info.scaled_size[1] / 1.8) * 0.5 &&
                    mouse_position.1 < (game_info.screen_offset[1] + game_info.scaled_size[1] / 1.8) + (game_info.scaled_size[1] - game_info.scaled_size[1] / 1.8) * 0.5 + ((game_info.scaled_size[1] - game_info.scaled_size[1] / 1.8) * 0.45){
                        game_info.game_state = std::process::exit(0);
                        play_sound_once(&game_info.game_sounds.menu_select)
                    }
                };
            }
        Playing => {
            let width = game_info.scaled_size[0];
            let height = game_info.scaled_size[1];

            let tilesize = f32::min(width, height) / (usize::min(game_info.level.width(), game_info.level.height()) as f32);

            let structure = &game_info.level.connection_structure;
            for y in 0..structure.len() {
                for x in 0..structure[y].len() {
                if structure[y][x] % 2 == 0 {
                    if structure[y][x] & 2 == 2 {
                        draw_texture_ex(
                        &game_info.game_textures.shaded_floor,
                        (x as f32 * tilesize + game_info.screen_offset[0]) + ((game_info.scaled_size[0] / 2.0) - (tilesize / 2.0 * structure[0].len() as f32)),
                        y as f32 * tilesize + game_info.screen_offset[1],
                        WHITE,DrawTextureParams 
                        {dest_size: Some(vec2(tilesize, tilesize)),..Default::default()})
                    }
                    else {
                        draw_texture_ex(
                        &game_info.game_textures.generic_floor,
                        (x as f32 * tilesize + game_info.screen_offset[0]) + ((game_info.scaled_size[0] / 2.0) - (tilesize / 2.0 * structure[0].len() as f32)),
                        y as f32 * tilesize + game_info.screen_offset[1],
                        WHITE,DrawTextureParams 
                        {dest_size: Some(vec2(tilesize, tilesize)),..Default::default()})
                    }
                }
                draw_texture_ex(
                    match structure[y][x] {
                        255 => 
                            if game_info.level_door_open {&game_info.game_textures.wall.door_wall_open} else {&game_info.game_textures.wall.door_wall}
                        ,
                        31 => &game_info.game_textures.wall.blocked,29 => &game_info.game_textures.wall.front,27 => &game_info.game_textures.wall.generic,25 => &game_info.game_textures.wall.generic,23 => &game_info.game_textures.wall.side_left,21 => &game_info.game_textures.wall.top_left,19 => &game_info.game_textures.wall.generic,17 => &game_info.game_textures.wall.generic,15 => &game_info.game_textures.wall.side_right,13 => &game_info.game_textures.wall.top_right,11 => &game_info.game_textures.wall.generic,9 => &game_info.game_textures.wall.generic,7 => &game_info.game_textures.wall.middle,5 => &game_info.game_textures.wall.top,3 => &game_info.game_textures.wall.generic,1 => &game_info.game_textures.wall.generic,0 => &game_info.game_textures.generic_floor,_ => &game_info.game_textures.generic_floor},
                    (x as f32 * tilesize + game_info.screen_offset[0]) + ((game_info.scaled_size[0] / 2.0) - (tilesize / 2.0 * structure[0].len() as f32)),
                    y as f32 * tilesize + game_info.screen_offset[1],
                    WHITE,DrawTextureParams 
                    {dest_size: Some(vec2(tilesize, tilesize)),..Default::default()});
                }
            };
            for guy in &mut game_info.level.guys {
                let mut offset = 1;
                if guy.velocity.0 != 0 || guy.velocity.1 != 0 {
                    guy.state_anim = 1;
                }
                let frames = match guy.sprite {
                            'S' => &game_info.game_textures.player,
                            'L' => &game_info.game_textures.enemies.lobster,
                            'M' => &game_info.game_textures.enemies.mimic,
                            'F' => &game_info.game_textures.enemies.potion,
                            'P' => &game_info.game_textures.enemies.pubert,
                            'U' => &game_info.game_textures.enemies.uncle_dragi,
                            _ => &game_info.game_textures.enemies.pubert
                        };
                if guy.state_anim == 0  || guy.state_anim == frames.len(){
                    offset = 0;
                }
                draw_texture_ex(
                    {
                        let anim_length = frames.len();
                        if guy.state_anim >= anim_length {guy.state_anim = 0};
                        &frames[guy.state_anim]
                    },
                    (guy.pos.0 as f32 * tilesize + game_info.screen_offset[0] + ((game_info.scaled_size[0] / 2.0) - (tilesize / 2.0 * structure[0].len() as f32))) - (tilesize * guy.last_velocity.0 as f32 * offset as f32) + ((tilesize * guy.last_velocity.0 as f32) / frames.len() as f32 * guy.state_anim as f32), 
                    guy.pos.1 as f32 * tilesize + game_info.screen_offset[1]  - (tilesize * guy.last_velocity.1 as f32 * offset as f32) + ((tilesize * guy.last_velocity.1 as f32) / frames.len() as f32 * guy.state_anim as f32),
                    WHITE,DrawTextureParams 
                    {dest_size: Some(vec2(tilesize, tilesize)),..Default::default()}
                );
                if guy.state_anim > 0 {guy.state_anim += 1};
            };
        },
        You_Win => {
            draw_texture_ex(
                &game_info.game_textures.you_win,
                game_info.screen_offset[0],
                game_info.screen_offset[1],
                WHITE,DrawTextureParams 
                {dest_size: Some(vec2(game_info.scaled_size[0], game_info.scaled_size[1])),..Default::default()} 
            );
        }
        _ => {/* error? */}
    }
}
//meow
pub fn find_scaled_size (
    screen_size: &Vec<f32>
) -> Vec<f32> {
    if screen_size[0] == screen_size[1] / 9.0 * 16.0 {
        return screen_size.clone()
    }
    let based_off_x = vec![screen_size[0], screen_size[0] / 16.0 * 9.0];
    let based_off_y = vec![screen_size[1] /9.0 * 16.0, screen_size[1]];
    if screen_size[1] >= based_off_x[1] {
        return based_off_x
    }
    else {
        return based_off_y
    }
}

fn render_options(
    top_left: &Vec<f32>,
    bottom_right: &Vec<f32>,
    game_info: &GameData
) {
    let option_height = (bottom_right[1] - top_left[1]) * 0.45;
    draw_texture_ex(
        &game_info.game_textures.play,
        top_left[0],
        top_left[1],
        WHITE,DrawTextureParams 
        {dest_size: Some(vec2(((game_info.scaled_size[0] + game_info.screen_offset[0]) - top_left[0]) / 2.0,option_height)),..Default::default()} 
    );
    draw_texture_ex(
        &game_info.game_textures.quit,
        top_left[0],
        top_left[1] + (option_height / 0.45 * 0.5),
        WHITE,DrawTextureParams 
        {dest_size: Some(vec2(((game_info.scaled_size[0] + game_info.screen_offset[0]) - top_left[0]) / 2.0,option_height)),..Default::default()} 
    );
}