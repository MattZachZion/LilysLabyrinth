use crate::data::GameData;
use crate::data::GameSounds;
use crate::gamedata::Tile::*;
use crate::gamedata::Direction::*;
use crate::bens_evil_vectors::{within, set_within, FuncList};
use macroquad::prelude::*;
use macroquad::audio::play_sound_once;
use crate::behaviour::*;
use std::fs;

pub enum Tile {
    X, O
}

impl Clone for Tile {
    fn clone(self: &Self) -> Self {
        match self {
            X => X,
            O => O
        }
    }
}

impl Copy for Tile {}

impl PartialEq for Tile {
    fn eq(self: &Self, other: &Self) -> bool {
        match (self, other) {
            (X, X) => true,
            (O, O) => true,
            _ => false
        }
    }
}

impl Eq for Tile {}

pub type Pos = (usize, usize);

pub fn pos_add((x1, y1): Pos, (x2, y2): Pos) -> (i32, i32) {
    (x2 as i32 + x1 as i32, y2 as i32 + y1 as i32)
}
pub fn pos_diff((x2, y2): Pos, (x1, y1): Pos) -> (i32, i32) {
    (x2 as i32 - x1 as i32, y2 as i32 - y1 as i32)
}

pub enum Direction {
    Up, Down, Left, Right, None
}

impl PartialEq for Direction {
    fn eq(self: &Self, other: &Self) -> bool {
        match (self, other) {
            (Up, Up) => true,
            (Down, Down) => true,
            (Left, Left) => true,
            (Right, Right) => true,
            (None, None) => true,
            _ => false
        }
    }
}

impl Eq for Direction {}

impl Clone for Direction {
    fn clone(self: &Self) -> Self {
        match self {
            Up => Up,
            Down => Down,
            Left => Left,
            Right => Right,
            None => None
        }
    }
}

impl Copy for Direction {}

pub fn dirmove((x, y): Pos, dir: Direction) -> Pos {
    match dir {
        Up => (x, i32::max(y as i32 - 1, 0) as usize),
        Down => (x, y + 1),
        Left => (i32::max(x as i32 - 1, 0) as usize, y),
        Right => (x + 1, y),
        None => (x, y)
    }
}

pub struct Guy {
    pub pos: Pos,
    pub state_movement: u32,
    pub state_death: u32,
    pub state_anim: usize,
    pub sprite: char,
    pub velocity: (i32, i32),
    pub last_velocity: (i32, i32),
    pub attack_velocity: (i32, i32),
    pub behaviour: fn(&mut Guy, &Maze) -> bool
}

impl Guy {
    pub fn behave(self: &mut Self, maze: &Maze) -> bool {
        let old_pos = self.pos;
        let player_killed = (self.behaviour)(self, maze);
        self.pos = (set_within(0, maze.width(), self.pos.0), set_within(0, maze.height(), self.pos.1));
        return player_killed;
    }

    pub fn dirmove(self: &mut Self, dir: Direction) {
        self.pos = dirmove(self.pos, dir);
    }
}

impl Clone for Guy {
    fn clone(self: &Self) -> Self {
        Guy {
            pos: self.pos,
            state_movement: self.state_movement,
            state_anim: self.state_anim,
            state_death: self.state_death,
            sprite: self.sprite,
            velocity: self.velocity,
            last_velocity: self.last_velocity,
            attack_velocity: self.attack_velocity,
            behaviour: self.behaviour
        }
    }
}

pub struct Maze {
    pub path: String,
    pub structure: Vec<Vec<Tile>>,
    pub guys: Vec<Guy>,
    pub player_index: usize,
    pub player_start_pos: Pos,
    pub door_pos: Pos,
    pub connection_structure: Vec<Vec<u8>>
}

impl Maze {
    pub fn width(self: &Self) -> usize {
        self.structure[0].len()
    }
    pub fn height(self: &Self) -> usize {
        self.structure.len()
    }

    pub fn player_index(self: &Self) -> usize {
        self.guys.find1st(|guy| guy.sprite == 'S')
    }

    pub fn get(self: &Self, (x, y): Pos) -> Tile {
        if !within(0, self.structure.len() - 1)(y) {
            return X;
        };
        if !within(0, self.structure[y].len() - 1)(x) {
            return X;
        };
        return self.structure[y][x];
    }

    pub fn calculate_connections(self: &mut Self) {
        self.connection_structure = vec![];
        for y in 0..self.height() {
            self.connection_structure.push(vec![]);
            for x in 0..self.width() {
                let is_x = (self.get((x, y)) == X) as u8;
                let up_x = (self.get((x, y - 1)) == X) as u8;
                let down_x = (self.get((x, y + 1)) == X) as u8;
                let left_x = (self.get((x - 1, y)) == X) as u8;
                let right_x = (self.get((x + 1, y)) == X) as u8;
                self.connection_structure[y].push(
                    is_x + 2*up_x + 4*down_x + 8*left_x + 16*right_x
                );
            }
        }
    }

    pub fn update(self: &mut Self, sounds: &GameSounds) -> bool {
        if self.guys[0].state_death > 0 {
            self.guys[0].state_death += 1;
            if self.guys[0].state_death < 10 {return false};
            let new_maze = get_level(self.path.as_str());
            self.guys = new_maze.guys;
        };

        let maze_copy = Maze {path: "".to_string(), structure: self.structure.clone(), guys: self.guys.clone(), player_index: 0, player_start_pos: self.player_start_pos, door_pos: self.door_pos, connection_structure: vec![]};
        let mut player_killed = false;
        let mut all_dead = true;

        for i in 0..self.guys.len() {
            if self.guys[i].state_death > 0 {continue};
            if i > 0 {all_dead = false};
            if i > 0 && self.guys[i].pos == self.guys[0].pos {
                self.guys[0].behaviour = match self.guys[i].sprite {
                    'F' => movement_player_flask,
                    'L' => movement_player_lobster,
                    'M' => movement_player_mimic,
                    'P' => movement_player_pubert,
                    _ => movement_player_default
                };
                self.guys[i].behaviour = movement_none;
                self.guys[i].state_death = 1;
                play_sound_once(&sounds.enemy_impact);
                play_sound_once(&sounds.enemy_soul);
                continue;
            };
            let old_pos = self.guys[i].pos;
            let local_player_killed = self.guys[i].behave(&maze_copy);
            let pos = self.guys[i].pos;
            if i > 0 {
                for n in 0..self.guys.len() {
                    if n == i {continue};
                    if self.guys[n].state_death > 0 {continue};
                    if self.guys[n].pos != pos {continue};
                    self.guys[i].pos = old_pos;
                    break;
                };
            };
            if self.get(pos) != O {
                self.guys[i].velocity = (0, 0);
                self.guys[i].pos = old_pos;
                continue;
            };
            self.guys[i].velocity = pos_diff(self.guys[i].pos, old_pos);
            if self.guys[i].velocity != (0, 0) {self.guys[i].last_velocity = self.guys[i].velocity};
            if local_player_killed {
                player_killed = true;
                self.guys[i].pos = self.guys[0].pos;
            };
        };
        if self.guys[0].velocity != (0, 0) {
            play_sound_once(&sounds.step);
        };
        if player_killed || is_key_down(KeyCode::R) {
            play_sound_once(&sounds.player_impact);
            play_sound_once(&sounds.player_soul);
            self.guys[0].behaviour = movement_none;
            self.guys[0].state_death = 1;
        };

        return all_dead;
    }
}

fn level_doc_to_maze(path: &str) -> (Vec<Vec<Tile>>, Vec<(char, Pos)>, Pos) {
    let raw_data: String = fs::read_to_string(path).expect("");
    let raw_1d: Vec<&str> = raw_data.split('\n').collect::<Vec<&str>>();
    let raw_2d: Vec<Vec<char>> = raw_1d.map(|row| row.chars().collect::<Vec<char>>().filter(|c| c != '\r'));
    let mut unique_positions: Vec<(char, Pos)> = vec![];
    let mut door_pos = (0, 0);
    for y in 0..raw_2d.len() {
        for x in 0..raw_2d[y].len() {
            let current = raw_2d[y][x];
            if current == 'D' {
                door_pos = (x, y);
                continue;
            };
            if current == '█' || current == ' ' {continue};
            unique_positions.push((current, (x, y)));
        };
    };
    return (
        raw_2d.map(|row| row.map(|c| match c {
            'D' => X,
            '█' => X,
            _ => O
        })),
        unique_positions,
        door_pos
    )
}

pub fn get_level(path: &str) -> Maze {
    let data = level_doc_to_maze("src/levels/{}.txt".replace("{}", path).as_str());
    let mut maze = Maze {
        path: path.to_string(),
        structure: data.0,
        guys: data.1.map(guy_from_char),
        player_index: 0,
        player_start_pos: (0, 0),
        door_pos: (0, 0),
        connection_structure: vec![]
    };
    maze.calculate_connections();
    maze.connection_structure[data.2.1][data.2.0] = 255;
    maze.door_pos = data.2;
    maze.player_index = maze.player_index();
    maze.guys = vec![vec![maze.player_index], (0..maze.guys.len()).collect::<Vec<usize>>().filter(|x| x != maze.player_index)]
        .concat()
        .map(|x| maze.guys[x].clone());
    maze.player_start_pos = maze.guys[maze.player_index].pos;
    maze
}