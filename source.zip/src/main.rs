use macroquad::prelude::*;
mod data;
use crate::data::*;
use crate::data::GameState::*;
mod gamedata;
use crate::gamedata::*;
mod render;
use crate::render::*;
mod behaviour;
use crate::behaviour::*;
mod bens_evil_vectors;
use crate::bens_evil_vectors::{within, set_within};
use std::time::Instant;
use macroquad::audio::{load_sound, play_sound, play_sound_once, PlaySoundParams};
use wasm_bindgen::prelude::*;


const TICK_RATE: f64 = 1./16.;

#[macroquad::main("Lilys Labyrinth")] 
#[wasm_bindgen(start)]
async fn main() {
    let levels = vec![
        "l12",
        "l22",
        "l32",
        "l42"
    ];
    let mut level_index = 0;
    let enemies: Enemies = Enemies {
        lobster: vec![load_texture("src/textures/enemies/Lobster_idle.png").await.unwrap(),load_texture("src/textures/lobster_walk/0.png").await.unwrap(),load_texture("src/textures/lobster_walk/1.png").await.unwrap(),load_texture("src/textures/lobster_walk/2.png").await.unwrap(),load_texture("src/textures/lobster_walk/3.png").await.unwrap()],
        mimic: vec![load_texture("src/textures/enemies/mimic_idle.png").await.unwrap(), load_texture("src/textures/mimic_lobber/0.png").await.unwrap(), load_texture("src/textures/mimic_lobber/1.png").await.unwrap(), load_texture("src/textures/mimic_lobber/2.png").await.unwrap(), load_texture("src/textures/mimic_lobber/3.png").await.unwrap(), load_texture("src/textures/mimic_lobber/4.png").await.unwrap()],
        potion: vec![load_texture("src/textures/enemies/potion_idle.png").await.unwrap(), load_texture("src/textures/weak_potion/0.png").await.unwrap(), load_texture("src/textures/weak_potion/1.png").await.unwrap(), load_texture("src/textures/weak_potion/2.png").await.unwrap()],
        pubert: vec![load_texture("src/textures/enemies/pubert_idle.png").await.unwrap(), load_texture("src/textures/the_jumper/0.png").await.unwrap(), load_texture("src/textures/the_jumper/1.png").await.unwrap(), load_texture("src/textures/the_jumper/2.png").await.unwrap(), load_texture("src/textures/the_jumper/3.png").await.unwrap(), load_texture("src/textures/the_jumper/4.png").await.unwrap(), load_texture("src/textures/the_jumper/5.png").await.unwrap()],
        uncle_dragi: vec![load_texture("src/textures/enemies/uncle_dragi_idle.png").await.unwrap(), load_texture("src/textures/Snake_skull/0.png").await.unwrap(), load_texture("src/textures/Snake_skull/1.png").await.unwrap()]
    };
    let walls: Walls = Walls {
        generic:  load_texture("src/textures/walls/wall_generic.png").await.unwrap(),
        top:  load_texture("src/textures/walls/n-wall.png").await.unwrap(),
        middle:  load_texture("src/textures/walls/11_wall.png").await.unwrap(),
        top_right:  load_texture("src/textures/walls/corner_wall_1.png").await.unwrap(),
        top_left:  load_texture("src/textures/walls/corner_wall_2.png").await.unwrap(),
        side_right:  load_texture("src/textures/walls/wall_side_right.png").await.unwrap(),
        side_left:  load_texture("src/textures/walls/wall_side_left.png").await.unwrap(),
        blocked:  load_texture("src/textures/walls/blocked.png").await.unwrap(),
        front:  load_texture("src/textures/walls/wall_front.png").await.unwrap(),
        door_wall:  load_texture("src/textures/walls/door_wall.png").await.unwrap(),
        door_wall_open:  load_texture("src/textures/walls/door_wall_open.png").await.unwrap()
    };
    let game_textures: GameTextures = GameTextures {
        main_menu_image: load_texture("src/textures/main_menu.png").await.unwrap(),
        you_win: load_texture("src/textures/you_win.png").await.unwrap(),
        wall: walls,
        generic_floor: load_texture("src/textures/floors/floor_basic.png").await.unwrap(),
        shaded_floor: load_texture("src/textures/floors/floor_shading_basic.png").await.unwrap(),
        player: vec![load_texture("src/textures/player/pip.png").await.unwrap(),
        load_texture("src/textures/player/walk_forward/0.png").await.unwrap(),
        load_texture("src/textures/player/walk_forward/1.png").await.unwrap(),
        load_texture("src/textures/player/walk_forward/2.png").await.unwrap(),
        load_texture("src/textures/player/walk_forward/3.png").await.unwrap()],
        play: load_texture("src/textures/play.png").await.unwrap(),
        quit: load_texture("src/textures/quit.png").await.unwrap(),
        enemies: enemies
    };
    let game_sounds = GameSounds {
        enemy_impact: load_sound("src/audio/enemyimpact.wav").await.unwrap(),
        enemy_soul: load_sound("src/audio/enemysoul.wav").await.unwrap(),
        menu_select: load_sound("src/audio/menuselect.wav").await.unwrap(),
        player_impact: load_sound("src/audio/playerimpact.wav").await.unwrap(),
        player_soul: load_sound("src/audio/playersoul.wav").await.unwrap(),
        step: load_sound("src/audio/step.wav").await.unwrap()
    };
    let mut game_info: GameData = GameData{
        game_state: Main_Menu,
        screen_size: vec![screen_width() as f32, screen_height() as f32],
        scaled_size: find_scaled_size(&vec![screen_width() as f32, screen_height() as f32]),
        screen_offset: vec![0.0, 0.0],
        game_textures: game_textures,
        game_sounds: game_sounds,
        level: get_level("l12"),
        level_door_open: false
    };
    game_info.screen_offset = vec![(game_info.screen_size[0] - game_info.scaled_size[0]) / 2.0, (game_info.screen_size[1] - game_info.scaled_size[1]) / 2.0];
    let mut time: f64 = 0.;
    let mut ticks: u32 = 0;
    loop {
        let now = Instant::now();
        
        render_game(&mut game_info);
        next_frame().await;
        
        let deltatime: f64 = now.elapsed().as_secs_f64();
        time += deltatime;
        if time < TICK_RATE {continue};
        time -= TICK_RATE;
        ticks += 1;

        match game_info.game_state {
            Playing => (),
            _ => continue
        };
        
        game_info.level_door_open = game_info.level.update(&game_info.game_sounds);
        
        if game_info.level_door_open 
            && dirmove(game_info.level.guys[0].pos, Direction::Up) == game_info.level.door_pos 
            && is_key_down(KeyCode::Space) {
            play_sound_once(&game_info.game_sounds.enemy_impact);
            level_index += 1;
            if level_index < levels.len() {
                game_info.level = get_level(levels[level_index]);
            } else {
                game_info.game_state = You_Win;
            }
        };
    };
}